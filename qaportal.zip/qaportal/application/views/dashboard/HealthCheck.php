<div id="container" class="container-fluid">
<div class="col-12 app-content">
			<div id="content">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<br>
<form method="post" action="runtestsnew.php" enctype="multipart/form-data">
  
   
        <table class =" table  table-striped  table-hover"  cellpadding="5" style="border-collapse:collapse;">
        <thead style="background-color: #e6e6e6; text-align: center;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <tr>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Execute Tests&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;System Health&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Audit Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        </tr>
        </thead><br><tbody>
        <tr>
        <td></td>
        <td></td>
        </tr>

        <tr>
        
        <td><div>
        <label style="text-align:right; margin-left:8px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                        
                    </div></td>&nbsp;
                    <td><div>
        <label style="text-align:right; margin-left:8px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date :&nbsp;&nbsp;&nbsp;&nbsp; </label>
                        
                    </div></td>
        <td>    
                        <div>
        <input type="text" value="02-23-2021" id="appurl" name="appurl" ><i class="fa fa-calendar"></input>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
      
        </tr>
        <tr>
        <td></td>
        <td></td>
        </tr>
        </tbody><br>
        <table width="100%" border="0" cellspacing="2" cellpadding="0">
                  <tr style="color: #666B85; font-size: 16px;">
                     <td>
                        <table  cellpadding="5" style="border-collapse:collapse;">
                           <tr style="color: black; font-size: 16px">
                              <th align="center" valign="middle" rowspan="2"                                    style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; color:inherit">                                        Project                                    </th>
                              <th align="center" valign="middle" rowspan="2" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">                                        CRON Job                                    </th>
                              <th align="center" valign="middle" rowspan="2" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Order Export Job</th>
                              <th align="center" valign="middle" rowspan="2" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Order Import Job</th>
                              <th align="center" valign="middle" rowspan="2" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Index Management</th>
                              <th align="center" valign="middle" rowspan="2" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Order Trackin Status</th>
                              <th align="center" valign="middle" colspan="2"                                    style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Google Insight Score </th>
                           </tr>
                           <tr style="color: black; font-size: 16px;">
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Web</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Mobile</th>
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style="background: yellow; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Hydroflask</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">
                                 Passed                                        
                                 <div>Previous total orders: <b>15698</b></div>
                                 <div>Current total orders: <b>15712</b></div>
                              </td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">83</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">63</td>
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style="background: yellow; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Revlon UK</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">
                                 Passed                                        
                                 <div>Previous total orders: <b>1096</b></div>
                                 <div>Current total orders: <b>1112</b></div>
                              </td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">89</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">71</td>
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style="background: yellow; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">PUR</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">
                                 Passed                                        
                                 <div>Previous total orders: <b>296</b></div>
                                 <div>Current total orders: <b>321</b></div>
                              </td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">37</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">13</td>
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style="background: yellow; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Braun</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Passed</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">
                                 Passed                                        
                                 <div>Previous total orders: <b>5496</b></div>
                                 <div>Current total orders: <b>6216</b></div>
                              </td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">82</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">54</td>
                           </tr>
                        </table>   
                </form>
            </div>
        </div>
</div>