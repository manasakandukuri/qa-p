<div id="container" class="container-fluid">
<div class="col-12 app-content">
			<div id="content">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<br>
<form method="post" action="runtestsnew.php" enctype="multipart/form-data">
  
   
        <table class =" table  table-striped  table-hover"  cellpadding="5" style="border-collapse:collapse;">
        <thead style="background-color: #e6e6e6; text-align: center;">
        <tr>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Execute Tests&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;System Health&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        <th >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Audit Report&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
        </tr>
        </thead><br><tbody>
        <tr>
        <td></td>
        <td></td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        </tr>
        <tr>
        <td></td>
        <td></td>
        </tr>
        </tbody><br>
        <table width="100%" border="0" cellspacing="2" cellpadding="0">
                  <tr style="color: #666B85; font-size: 16px;">
                     <td>
                        <table  cellpadding="5" style="border-collapse:collapse;">
                           <tr style="color: black; font-size: 16px">
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; color:inherit">Project</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Environment</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Testing Type</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Browser</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Scheduled AT</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Status</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Triggered by</th>
                              <th align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Emails</th>
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Hydroflask</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Production</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Web</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Chrome</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">06-02-2021  02:00:00</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Running</td> 
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">mchiruvella@helenoftroy.com</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">mchiruvella@helenoftroy.com</td> 
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">PUR</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Staging</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Mobile</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">iPhone X</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">04-02-2021  18:00:00</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Completed</td> 
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">makoppanaadham@helenoftroy.com</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">makoppanaadham@helenoftroy.com</td> 
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Revlon UK</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Development</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Mobile</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">iPad</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">07-02-2021  02:00:00</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Queued</td> 
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">hchiruvella@helenoftroy.com</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">hchiruvella@helenoftroy.com</td> 
                           </tr>
                           <tr style="color: #666B85; font-size: 16px;">
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif;">Hot Tools</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Development</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Web</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Firefox</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">23-02-2021  14:00:00</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Failed to Trigger</td> 
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">rmaddi@helenoftroy.com</td>
                              <td align="center" valign="middle" style=" border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">rmaddi@helenoftroy.com</td> 
                           </tr>
                        </table>   
                </form>
            </div>
        </div>
</div>