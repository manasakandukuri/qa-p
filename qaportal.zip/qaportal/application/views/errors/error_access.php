<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Access error</title>
    <link rel="stylesheet" href="<?php echo base_url();?>css/style.css" />
</head>
<body>
<br><br><br><br><br><br><br><br><br>
    <h2 style="text-align: center;">   You do not have access to this page! </h2>
    <!-- <?php $this->load->library('session'); print_r($_SESSION['navigation']); ?> -->
</body>
</html>
