// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable({

   "bLengthChange" : false,
   "bInfo":false, 

  });
});
