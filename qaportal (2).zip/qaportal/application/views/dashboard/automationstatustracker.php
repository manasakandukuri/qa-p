<div id="container" class="container-fluid">
	<div class="row flex-xl-nowrap">
		<div class="col-12 app-content">
			<div id="content">
			<br>
				<h2 class="main-title">Safety Net Automation Coverage</h2>
				<table cellpadding="5" style="border-collapse:collapse;">
					<tr>
						<td width="15%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">DI</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Common Areas</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Reporting</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Ops Planning</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">WFP</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Consolidation</td>
						<td width="10%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Revenue Planning</td>
						<td width="15%" align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Total</td>
					</tr>
					<tr>
						<td align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Total Test Cases</td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
					</tr>
					<tr>
						<td align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Manual</td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
					</tr>
					<tr>
						<td align="center" valign="middle" style="background:#e2e2e2; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; ">Automated</td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
						<td align="center" valign="middle" style="background:#FFFFFF; border:1px solid #b6b6b6; font:bold 13px 'Segoe UI', Arial, Helvetica, sans-serif; "></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>